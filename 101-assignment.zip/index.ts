function helloWorld(name: string) {
    return "Hello " + name;
}

console.log(helloWorld("Bill"));
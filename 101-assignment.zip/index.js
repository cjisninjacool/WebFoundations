"use strict";
function helloWorld(name) {
    return "Hello " + name;
}
console.log(helloWorld("Bill"));

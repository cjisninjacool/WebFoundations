"use strict";
let contact = {
    contactName: "Bob",
    dob: "02/02/94",
    role: "student"
};
let { contactName, dob, role } = contact;
console.log(contactName + " is a " + role + " learning to code and was born on " + dob);

export class Job {
  id: number = 1;
  title: string = "Job Title";
  description!: string;
  duration!: string;
  employer!: string;
}
